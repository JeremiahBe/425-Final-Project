/*
 * @file Lock_System.c
 * @brief Source file for the Lock System logic used in the Digital Lock project.
 *        This module handles digit entry storage, passcode verification, code reset, 
 *        and admin code detection to manage access control behavior.
 *
 * @note This driver assumes that the system clock's frequency is 50 MHz.
 * @note Supports storage and comparison of 4-digit numeric codes (values 1�15).
 * @note Includes functionality for both user code and admin override code logic.
 * @note Provides interface to reset the system state and update the stored passcode at runtime.
 * @note All values are held in RAM (non-persistent) unless additional storage is added.
 *
 * @author Jeremiah Bennett
 */

#include "Lock_System.h"

static int entered_code[NUM_DIGITS] = {0};
static const int correct_code[NUM_DIGITS] = {1, 1, 1, 1};

void LockSystem_Init(void)
{
    for (int i = 0; i < NUM_DIGITS; i++)
    {
        entered_code[i] = 0;
    }
}

void LockSystem_Reset(void)
{
    for (int i = 0; i < NUM_DIGITS; i++)
    {
        entered_code[i] = 0;
    }
}

void LockSystem_SetDigit(int index, int value)
{
    if (index >= 0 && index < NUM_DIGITS)
    {
        entered_code[index] = value;
    }
}

bool LockSystem_CheckCode(void)
{
    for (int i = 0; i < NUM_DIGITS; i++)
    {
        if (entered_code[i] != correct_code[i])
        {
            return false;
        }
    }
    return true;
}